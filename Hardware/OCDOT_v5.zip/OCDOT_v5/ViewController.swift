//
//  ViewController.swift
//  OCDOT_v5
//
//  Created by Veronica Marie Bella on 2/4/23.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {
    @IBOutlet weak var gyrox: UILabel!
    @IBOutlet weak var gyroy: UILabel!
    @IBOutlet weak var gyroz: UILabel!
    @IBOutlet weak var accelx: UILabel!
    @IBOutlet weak var accely: UILabel!
    @IBOutlet weak var accelz: UILabel!
    
    var motion = CMMotionManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        MyGyro()
        // Do any additional setup after loading the view.
    }
    
    func MyGyro() {
        motion.gyroUpdateInterval = 0.5
        motion.startGyroUpdates(to: OperationQueue.current!){(data, error) in
            if let trueData = data{
                print(trueData)
            }
        }
    }


}

